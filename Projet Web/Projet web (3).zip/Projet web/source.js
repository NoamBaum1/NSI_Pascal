
window.onload = function () {
    alert("Après cette formation détendez-vous");
};

// THEME (COULEURS ALEATOIRES)
document.getElementById("themeBtn").onclick = function () {
    const r = Math.floor(Math.random() * 255);
    const g = Math.floor(Math.random() * 255);
    const b = Math.floor(Math.random() * 255);

    document.body.style.background = `rgb(${r}, ${g}, ${b})`;
};

// CARROUSEL
const images = [
    "mer.jpg",
    "montagne.jpg",
    "nature.jpg",
    "savane.jpg"
];

let index = 0;

function show() {
    document.getElementById("carouselImage").src = images[index];
}

function nextImage() {
    index = (index + 1) % images.length;
    show();
}

function prevImage() {
    index = (index - 1 + images.length) % images.length;
    show();
}

